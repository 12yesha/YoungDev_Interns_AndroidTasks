package com.example.simplegame;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Find views
        ImageView imageView1 = findViewById(R.id.imageView2);
        ImageView imageView2 = findViewById(R.id.imageView3);
        ImageView imageView3 = findViewById(R.id.imageView4);
        ImageView imageView4 = findViewById(R.id.imageView5);
        ImageView imageView5 = findViewById(R.id.imageView6);
        ImageView imageView6 = findViewById(R.id.imageView7);

        // Set click listeners for image views
        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToActivity("Multitalented");
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToActivity("Leaders");
            }
        });

        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToActivity("Learners");
            }
        });

        imageView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToActivity("Developers");
            }
        });

        imageView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToActivity("Programmers");
            }
        });

        imageView6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToActivity("IT Experts");
            }
        });
    }

    // Method to navigate to another activity or perform an action based on the clicked category
    private void goToActivity(String category) {
        // Example: Toast a message with the selected category
        Toast.makeText(this, "Clicked " + category, Toast.LENGTH_SHORT).show();

        // Add code here to start a new activity or perform an action based on the clicked category
        // For example:
        /*
        Intent intent = new Intent(HomeActivity.this, AnotherActivity.class);
        intent.putExtra("CATEGORY_KEY", category);
        startActivity(intent);
        */
    }
}
