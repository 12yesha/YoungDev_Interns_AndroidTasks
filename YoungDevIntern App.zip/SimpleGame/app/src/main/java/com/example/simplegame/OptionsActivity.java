package com.example.simplegame;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class OptionsActivity extends AppCompatActivity {

    private Button homeButton;
    private Button aboutButton;
    private Button internshipsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);

        // Find buttons by their IDs
        homeButton = findViewById(R.id.button);
        aboutButton = findViewById(R.id.button2);
        internshipsButton = findViewById(R.id.button3);

        // Set click listeners for each button
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click for Home button
                // Example: Navigate to HomeActivity
                Intent intent = new Intent(OptionsActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });

        aboutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click for About button
                // Example: Navigate to AboutActivity
                Intent intent = new Intent(OptionsActivity.this, AboutActivity.class);
                startActivity(intent);
            }
        });

        internshipsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click for Internships button
                // Example: Navigate to InternshipsActivity
                Intent intent = new Intent(OptionsActivity.this, InternshipActivity.class);
                startActivity(intent);
            }
        });
    }
}
